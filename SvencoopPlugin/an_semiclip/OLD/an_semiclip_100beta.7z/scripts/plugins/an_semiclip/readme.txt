Add this text to "svencoop/default_plugins.txt" in order to enable semiclip plugin:

	"plugin"
	{
		"name" "AN Semiclip"
		"script" "an_semiclip/an_semiclip"
	}